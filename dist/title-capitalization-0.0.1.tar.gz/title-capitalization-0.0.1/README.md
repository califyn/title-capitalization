# title-cap

A simple package to capitalize text according to title capitalization conventions.

Written for CSC630 in fall 2020 by Sarah, Gaia, Nikol, and Ali
